package com.finnovator.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.finnovator.entity.Response;
import com.finnovator.entity.User;
import com.finnovator.service.AuthService;

@RestController
public class AuthenticateController {
	
	private static final Logger logger = LoggerFactory .getLogger(AuthenticateController.class);

	@Autowired
	private AuthService authService;

	@RequestMapping(value = "/authEmpId", method = RequestMethod.POST, consumes = "application/json")
	public ResponseEntity<Response> authEmpId(@RequestBody User user) {
		HttpHeaders responseHeaders = new HttpHeaders();
		Response response = new Response();
		boolean flag = false;

		if (user != null) {
			String userId = user.getUserId();

			if (userId != null && !userId.isEmpty()) {
				flag = authService.authenticateUserId(userId);
				//SecureRandom random = new SecureRandom();
				logger.info("Employee ID Authenticated Successfully.. ");
				//logger.info("OTP is Generated for "+ userId +": "+ new BigInteger(50, random).toString(32).toUpperCase());
			}
		}

		if (flag) {
			response.setStatusCode(HttpStatus.OK.toString());
			response.setMessage("Valid User ID.");
			return new ResponseEntity<Response>(response, responseHeaders, HttpStatus.OK);
		}

		response.setErrorCode(HttpStatus.BAD_REQUEST.toString());
		response.setErrorMessage("Not Valid User ID.");
		return new ResponseEntity<Response>(response, responseHeaders, HttpStatus.OK);

	}

	@RequestMapping(value = "/list", method = RequestMethod.POST)
	public ResponseEntity<List<User>> getUsers() {
		HttpHeaders responseHeaders = new HttpHeaders();
		return new ResponseEntity<List<User>>(authService.getListOfUsers(), responseHeaders, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/authPass", method = RequestMethod.POST, consumes = "application/json")
	public ResponseEntity<Response> authPass(@RequestBody User user) {
		HttpHeaders responseHeaders = new HttpHeaders();
		Response response = new Response();
		boolean flag = false;

		if (user != null) {
			String password = user.getPassword();
			String otp = user.getOtp();

			if (password != null && !password.isEmpty() && otp != null && !otp.isEmpty()) {
				flag = authService.authenticatePassword(otp, password);
			}
		}

		if (flag) {
			response.setStatusCode(HttpStatus.OK.toString());
			response.setMessage("Password and OTP is Valid.");
			return new ResponseEntity<Response>(response, responseHeaders, HttpStatus.OK);
		}

		response.setErrorCode(HttpStatus.BAD_REQUEST.toString());
		response.setErrorMessage("Password or OTP is not Valid.");
		return new ResponseEntity<Response>(response, responseHeaders, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/saveUser", method = RequestMethod.POST, consumes = "application/json")
	public ResponseEntity<Response> saveUser(@RequestBody User user) {
		HttpHeaders responseHeaders = new HttpHeaders();
		Response response = new Response();
		
		if(user != null)
		authService.saveUser(user);
		
		response.setStatusCode(HttpStatus.OK.toString());
		response.setMessage("Password and OTP is Valid.");
		return new ResponseEntity<Response>(response, responseHeaders, HttpStatus.OK);
	}

}
