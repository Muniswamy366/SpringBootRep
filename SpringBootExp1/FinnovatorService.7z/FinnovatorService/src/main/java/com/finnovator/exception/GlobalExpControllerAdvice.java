package com.finnovator.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.finnovator.entity.Response;

@ControllerAdvice
public class GlobalExpControllerAdvice {

	@ExceptionHandler(Exception.class)
	public ResponseEntity<Response> handleException(HttpServletRequest request, Exception ex) {
		Response error = new Response();
		error.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
		error.setErrorMessage("Please contact your administrator");
		return new ResponseEntity<Response>(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}