package com.finnovator.dao;

import java.util.List;

import com.finnovator.entity.User;

public interface AuthDao {
	
	List<User> getListOfUsers();
	
	void updateUserwithOtp(String userid,  String otp);
	
	public void saveUser(User user);
	
}
