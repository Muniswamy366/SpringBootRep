package com.finnovator.entity;

public class Response {

	private String statusCode;

	private String errorCode;

	private String message;

	private String errorMessage;
	
	public Response() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Response(String statusCode, String errorCode, String message, String errorMessage) {
		super();
		this.statusCode = statusCode;
		this.errorCode = errorCode;
		this.message = message;
		this.errorMessage = errorMessage;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
}
