package com.finnovator.daoImpl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.finnovator.dao.AuthDao;
import com.finnovator.entity.User;

@Repository("authDao")
public class AuthDaoImpl implements AuthDao{

	private static final Logger logger = LoggerFactory .getLogger(AuthDaoImpl.class);
	
	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<User> getListOfUsers() {
		Session session = sessionFactory.openSession();
		Criteria criteria = session.createCriteria(User.class);
		logger.debug("Got the data from DB :"+criteria.list());
		return criteria.list();
	}
	
	@Override
	public void updateUserwithOtp(String userid, String otp)
	{
		Session session = sessionFactory.openSession();
		User user = (User) session.get(userid, User.class);
		Transaction tx = session.beginTransaction();
		user.setOtp(otp);
		tx.commit();
		session.close();
	}

	@Override
	public void saveUser(User user) {
		Session session = sessionFactory.openSession();
		session.saveOrUpdate(user);
		session.close();
	}

}
