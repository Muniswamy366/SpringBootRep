package com.finnovator.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.finnovator.dao.AuthDao;
import com.finnovator.entity.User;

@Service("authService")
public class AuthService {
	
	private static final Logger logger = LoggerFactory .getLogger(AuthService.class);

	@Autowired
	private AuthDao authDao;
	
	/*@Autowired
	private EmailService emailService;*/
	
	public List<User> getListOfUsers()
	{
		return authDao.getListOfUsers();
	}
	
	public boolean authenticateUserId(String userId)
	{
		List<User> listOfUsers = authDao.getListOfUsers();
		for (User user : listOfUsers) {
			if(user.getUserId().equalsIgnoreCase(userId))
			{
				//SecureRandom random = new SecureRandom();
				//String otp = new BigInteger(50, random).toString(32).toUpperCase();
				//emailService.sendMail("muniswamy.palla@fisglobal.com", "OTP", "Generated OTP : "+otp);
				//logger.debug("Generated OTP : "+otp);
				//authDao.updateUserwithOtp(userId, otp);
				return true;
			}
		}
		return false;
	}
	
	public boolean authenticatePassword(String otp, String password)
	{
		List<User> listOfUsers = authDao.getListOfUsers();
		for (User user : listOfUsers) {
			if(user.getOtp().equalsIgnoreCase(otp) && user.getPassword().equalsIgnoreCase(password))
			return true;
		}
		return false;
	}
	
	public void saveUser(User user)
	{
		
	}
}
