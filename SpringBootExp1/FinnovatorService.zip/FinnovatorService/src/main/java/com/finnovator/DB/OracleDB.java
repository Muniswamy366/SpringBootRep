package com.finnovator.DB;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.finnovator.entity.User;

@Component("oracleDB")
public class OracleDB {

	List<User> users = new ArrayList<User>();
			
	public OracleDB()
	{
		users.add(new User("e1234", "user", "pass", "user@gmail.com", "1234"));
	}
	
	public List<User> getUsersFromDB()
	{
		return users;
	}

}
