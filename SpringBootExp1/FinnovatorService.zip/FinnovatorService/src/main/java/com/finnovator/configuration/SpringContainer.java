package com.finnovator.configuration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages={"com.finnovator"})
public class SpringContainer {

	public static void main(String[] args) {
		SpringApplication.run(SpringContainer.class, args);
	}
}
